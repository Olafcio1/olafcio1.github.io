#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 vrtx = vertexColor;

    if (vrtx.r >= 0.27 && vrtx.r < 0.28) {
        if (vrtx.g >= 0.27 && vrtx.g < 0.28) {
            if (vrtx.b == 0) {
                vrtx.r = 0;
                vrtx.g = 0;
                vrtx.b = 0;
            }
        }
    }

    vec4 color = texture(Sampler0, texCoord0) * vrtx * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
