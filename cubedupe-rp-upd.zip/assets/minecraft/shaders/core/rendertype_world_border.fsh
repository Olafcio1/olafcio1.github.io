#version 330

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }

    color.r = 255;

    float limit = 30.0;
    float half = limit/2;

    float g = mod(texCoord0.y, limit);
    if (g > half)
        g = half - (g - half);

    color.g = (g / limit) * 6;
    color.b = 0;

    fragColor = color * ColorModulator;
}
