#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;

out vec4 fragColor;

void main() {
    int a = 0;
    for (int i = 0; i < 100000; i++) {
        a += 1;
    }

    fragColor = vec4(255 * a, 255 * a, 255 * a, 0);
}
